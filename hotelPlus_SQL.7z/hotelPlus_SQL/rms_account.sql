create table account
(
    id        int auto_increment
        primary key,
    name      varchar(32)      not null,
    password  varchar(32)      not null,
    real_name varchar(32)      null,
    id_card   varchar(32)      null,
    mobile    varchar(16)      null,
    address   varchar(128)     null,
    status    int(1) default 0 null,
    qid       int              null
);

INSERT INTO rms.account (id, name, password, real_name, id_card, mobile, address, status, qid) VALUES (1, '猿来入此', '111111', '猿来入此', '62225225666552', '13656565656', '上海 浦东', 0, null);
INSERT INTO rms.account (id, name, password, real_name, id_card, mobile, address, status, qid) VALUES (2, '张三', '123', '张三五', '4622987745565656', '13912233333', '北京 三里屯 酒吧', 0, null);
INSERT INTO rms.account (id, name, password, real_name, id_card, mobile, address, status, qid) VALUES (3, '李四', '123', '李四', '6565656565656', '13999999999', '南京', 0, null);
INSERT INTO rms.account (id, name, password, real_name, id_card, mobile, address, status, qid) VALUES (4, '王麻子', '123', '大刀王五', '110110120121110110', '13656565656', '北京 朝阳区 群众', -1, null);
INSERT INTO rms.account (id, name, password, real_name, id_card, mobile, address, status, qid) VALUES (5, '老刘', '123456', '张小明', '31012002522555', '13545455454', '江苏 南京', 0, null);
INSERT INTO rms.account (id, name, password, real_name, id_card, mobile, address, status, qid) VALUES (9, '13541633683', '111111', '张小明', '31012002522555', '13656565656', '四川成都', 0, null);
INSERT INTO rms.account (id, name, password, real_name, id_card, mobile, address, status, qid) VALUES (10, '19983438835', '123456', 'ggdg', '56116161553', '5618186485', 'dgdgdgd', 0, null);
INSERT INTO rms.account (id, name, password, real_name, id_card, mobile, address, status, qid) VALUES (27, '13006077798', '222222', '张三', '31012002522555233', '13912233333', '成都', 0, 23);
INSERT INTO rms.account (id, name, password, real_name, id_card, mobile, address, status, qid) VALUES (28, '15806316316', '123456', null, null, null, null, 0, 24);
INSERT INTO rms.account (id, name, password, real_name, id_card, mobile, address, status, qid) VALUES (29, '13207084932', '123456', null, null, null, null, 0, 25);
INSERT INTO rms.account (id, name, password, real_name, id_card, mobile, address, status, qid) VALUES (30, '15807130891', '123456', null, null, null, null, 0, 26);