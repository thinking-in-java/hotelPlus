create table qq_account
(
    id           int auto_increment
        primary key,
    openid       varchar(100) null,
    access_token varchar(100) null,
    nickname     text         null,
    photo_url    varchar(150) null
)
    charset = utf8mb4;

INSERT INTO rms.qq_account (id, openid, access_token, nickname, photo_url) VALUES (23, '3BD0F366B5DB34D2146A91F11D570077', 'AD93BC9D72C02BC2A719B02BB59F671B', '🍀Lucky Dog🍀', 'http://qzapp.qlogo.cn/qzapp/101897224/3BD0F366B5DB34D2146A91F11D570077/100');
INSERT INTO rms.qq_account (id, openid, access_token, nickname, photo_url) VALUES (24, 'EFB541499B50FDB8902C8D563C7107A3', '9D222A592E0D474A20991307BACBE808', 'ᴮᵉ ʰᵃᵖᵖʸ', 'http://qzapp.qlogo.cn/qzapp/101897224/EFB541499B50FDB8902C8D563C7107A3/100');
INSERT INTO rms.qq_account (id, openid, access_token, nickname, photo_url) VALUES (25, '7E58E9E7E9C8A698D4CBBD1D2B0629A7', '6AC3CE5681DB719EFEBE176DC6554169', 'ㄣ 海风掠过北极光 ★', 'http://qzapp.qlogo.cn/qzapp/101897224/7E58E9E7E9C8A698D4CBBD1D2B0629A7/100');
INSERT INTO rms.qq_account (id, openid, access_token, nickname, photo_url) VALUES (26, 'D785D3496BBE85191DF1F89C974B5B9E', 'F9C7909725EA1EB575A6D9A93E525F5E', '♚', 'http://qzapp.qlogo.cn/qzapp/101897224/D785D3496BBE85191DF1F89C974B5B9E/100');