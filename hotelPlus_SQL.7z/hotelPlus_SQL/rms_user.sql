create table user
(
    id              bigint(19) auto_increment
        primary key,
    loginname       varchar(64)              not null,
    name            varchar(64)              not null,
    password        varchar(64)              not null,
    sex             tinyint(2)   default 0   not null,
    age             tinyint(2)   default 0   null,
    usertype        tinyint(2)   default 0   not null,
    status          tinyint(2)   default 0   not null,
    organization_id varchar(100) default '0' not null,
    createdate      datetime                 not null,
    phone           varchar(20)              null,
    lastlogintime   datetime                 null
)
    comment '用户';

INSERT INTO rms.user (id, loginname, name, password, sex, age, usertype, status, organization_id, createdate, phone, lastlogintime) VALUES (14, 'feng', 'feng', 'ada1be43ad606a0131b74c44b88c2dd2', 1, 25, 1, 0, '6', '2018-12-29 17:40:18', '18707173376', '2020-08-06 11:09:10');
INSERT INTO rms.user (id, loginname, name, password, sex, age, usertype, status, organization_id, createdate, phone, lastlogintime) VALUES (15, 'test', '测试账户', 'b0ce72ed0b24728785094ef90b6d00c3', 0, 6, 1, 0, '6', '2019-01-21 15:21:19', '18707173376', '2020-08-07 17:30:28');
INSERT INTO rms.user (id, loginname, name, password, sex, age, usertype, status, organization_id, createdate, phone, lastlogintime) VALUES (16, 'admin', 'Mr.YiQuan', 'd0e94b2754ccdf7e17c42919206b9b3d', 0, 20, 1, 0, '1', '2020-08-06 00:03:45', '18296633676', '2020-08-07 17:33:22');
INSERT INTO rms.user (id, loginname, name, password, sex, age, usertype, status, organization_id, createdate, phone, lastlogintime) VALUES (18, 'test2', '测试账户2', '191dd868a777ff98f650c59d87ed6563', 1, 20, 1, 0, '3', '2019-02-18 00:34:47', '12306', '2020-08-06 11:09:13');
INSERT INTO rms.user (id, loginname, name, password, sex, age, usertype, status, organization_id, createdate, phone, lastlogintime) VALUES (19, 'test3', '测试账户3', '326f03ff1f335b2583041c6239c25777', 0, 14, 1, 0, '5', '2019-01-24 10:51:00', '12345609', '2020-08-06 11:09:14');
INSERT INTO rms.user (id, loginname, name, password, sex, age, usertype, status, organization_id, createdate, phone, lastlogintime) VALUES (20, 'tttttt', 'tttttt', 'ef88ef38744735085452ac683540e735', 0, 0, 1, 0, '1', '2020-08-06 10:07:02', '', '2020-08-06 10:38:59');