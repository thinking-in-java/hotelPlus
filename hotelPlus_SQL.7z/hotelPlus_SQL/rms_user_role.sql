create table user_role
(
    id      bigint(19) auto_increment
        primary key,
    user_id bigint(19) not null,
    role_id bigint(19) not null
)
    comment '用户角色';

INSERT INTO rms.user_role (id, user_id, role_id) VALUES (164, 18, 8);
INSERT INTO rms.user_role (id, user_id, role_id) VALUES (214, 34, 10);
INSERT INTO rms.user_role (id, user_id, role_id) VALUES (215, 35, 2);
INSERT INTO rms.user_role (id, user_id, role_id) VALUES (254, 14, 1);
INSERT INTO rms.user_role (id, user_id, role_id) VALUES (256, 16, 1);
INSERT INTO rms.user_role (id, user_id, role_id) VALUES (257, 19, 10);
INSERT INTO rms.user_role (id, user_id, role_id) VALUES (259, 20, 1);
INSERT INTO rms.user_role (id, user_id, role_id) VALUES (261, 15, 8);