create table checkin
(
    id            int auto_increment
        primary key,
    room_id       int              not null,
    room_type_id  int              not null,
    checkin_price float(8, 2)      not null,
    name          varchar(32)      not null,
    id_card       varchar(32)      null,
    mobile        varchar(16)      null,
    status        int(1) default 0 null,
    arrive_date   varchar(32)      null,
    leave_date    varchar(32)      not null,
    book_order_id int              null,
    remark        varchar(128)     null,
    create_time   datetime         not null,
    constraint checkin_ibfk_1
        foreign key (room_id) references room (id),
    constraint checkin_ibfk_2
        foreign key (room_type_id) references room_type (id)
);

create index accountId
    on checkin (room_id);

create index roomTypeId
    on checkin (room_type_id);

INSERT INTO rms.checkin (id, room_id, room_type_id, checkin_price, name, id_card, mobile, status, arrive_date, leave_date, book_order_id, remark, create_time) VALUES (9, 2, 1, 123, 'wq', 'ewq', 'ewq', 1, '2019-01-18', '2019-01-19', null, '', '2019-01-18 23:57:55');
INSERT INTO rms.checkin (id, room_id, room_type_id, checkin_price, name, id_card, mobile, status, arrive_date, leave_date, book_order_id, remark, create_time) VALUES (10, 4, 3, 298, '张三五', '622987745565656', '13918655256', 1, '2019-01-18', '2019-01-19', 11, '', '2019-01-19 00:00:08');
INSERT INTO rms.checkin (id, room_id, room_type_id, checkin_price, name, id_card, mobile, status, arrive_date, leave_date, book_order_id, remark, create_time) VALUES (11, 2, 1, 198, '猿来入此', '62225225666552', '13656565656', 1, '2019-01-18', '2019-01-19', 10, '猿来入此', '2019-01-19 00:32:15');
INSERT INTO rms.checkin (id, room_id, room_type_id, checkin_price, name, id_card, mobile, status, arrive_date, leave_date, book_order_id, remark, create_time) VALUES (12, 3, 2, 299, '小明', '31012002522555', '13545455454', 1, '2019-01-19', '2019-01-20', 14, '帮我留一个有窗户的靠南的！谢谢！', '2019-01-19 23:05:23');
INSERT INTO rms.checkin (id, room_id, room_type_id, checkin_price, name, id_card, mobile, status, arrive_date, leave_date, book_order_id, remark, create_time) VALUES (13, 6, 6, 200, '小明', '31012002522555', '13545455454', 1, '2019-01-21', '2019-01-22', 15, '我会尽快赶来,haha！', '2019-01-19 23:08:57');
INSERT INTO rms.checkin (id, room_id, room_type_id, checkin_price, name, id_card, mobile, status, arrive_date, leave_date, book_order_id, remark, create_time) VALUES (14, 3, 2, 189, '马冬梅', '65656465656565656', '13848484878', 1, '2019-01-20', '2019-01-22', null, '马冬梅', '2019-01-20 15:33:14');
INSERT INTO rms.checkin (id, room_id, room_type_id, checkin_price, name, id_card, mobile, status, arrive_date, leave_date, book_order_id, remark, create_time) VALUES (15, 4, 3, 659, '张小帅', '62225225666552', '13656565656', 1, '2019-01-16', '2019-01-18', null, '测试数据', '2019-01-20 15:34:49');
INSERT INTO rms.checkin (id, room_id, room_type_id, checkin_price, name, id_card, mobile, status, arrive_date, leave_date, book_order_id, remark, create_time) VALUES (16, 2, 1, 168, '猿来入此', '62225225666552', '13656565656', 0, '2019-01-20', '2019-01-22', null, '猿来入此站长', '2019-01-20 15:36:26');
INSERT INTO rms.checkin (id, room_id, room_type_id, checkin_price, name, id_card, mobile, status, arrive_date, leave_date, book_order_id, remark, create_time) VALUES (17, 3, 2, 189, '马冬', '65656465656565656', '13848484878', 1, '2019-01-20', '2019-01-22', null, '马冬梅', '2019-01-20 15:33:14');
INSERT INTO rms.checkin (id, room_id, room_type_id, checkin_price, name, id_card, mobile, status, arrive_date, leave_date, book_order_id, remark, create_time) VALUES (18, 3, 2, 189, '马冬', '65656465656565656', '13848484878', 1, '2019-01-20', '2019-01-22', null, '马冬梅', '2018-11-20 15:33:14');
INSERT INTO rms.checkin (id, room_id, room_type_id, checkin_price, name, id_card, mobile, status, arrive_date, leave_date, book_order_id, remark, create_time) VALUES (19, 3, 2, 189, '马冬', '65656465656565656', '13848484878', 1, '2019-01-20', '2019-01-22', null, '马冬梅', '2018-12-22 15:33:14');
INSERT INTO rms.checkin (id, room_id, room_type_id, checkin_price, name, id_card, mobile, status, arrive_date, leave_date, book_order_id, remark, create_time) VALUES (20, 3, 2, 189, '马军', '65656465656565656', '13848484878', 1, '2019-01-20', '2019-01-22', null, '马冬梅', '2018-10-22 15:33:14');
INSERT INTO rms.checkin (id, room_id, room_type_id, checkin_price, name, id_card, mobile, status, arrive_date, leave_date, book_order_id, remark, create_time) VALUES (21, 3, 2, 189, '马军', '65656465656565656', '13848484878', 1, '2019-01-20', '2019-01-22', null, '马冬梅', '2019-01-12 15:33:14');
INSERT INTO rms.checkin (id, room_id, room_type_id, checkin_price, name, id_card, mobile, status, arrive_date, leave_date, book_order_id, remark, create_time) VALUES (22, 3, 2, 189, '马军', '65656465656565656', '13848484878', 1, '2019-01-20', '2019-01-22', null, '马冬梅', '2018-11-12 15:33:14');
INSERT INTO rms.checkin (id, room_id, room_type_id, checkin_price, name, id_card, mobile, status, arrive_date, leave_date, book_order_id, remark, create_time) VALUES (23, 3, 2, 589, '马军', '65656465656565656', '13848484878', 1, '2019-01-20', '2019-01-22', null, '马冬梅', '2018-11-17 15:33:14');
INSERT INTO rms.checkin (id, room_id, room_type_id, checkin_price, name, id_card, mobile, status, arrive_date, leave_date, book_order_id, remark, create_time) VALUES (25, 3, 10, 1, '小明', '31012002522555', '13545455454', 1, '2019-01-21', '2019-01-23', 16, '奢侈一把！6666', '2020-08-04 23:31:41');