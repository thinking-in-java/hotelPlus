create table organization
(
    id         bigint(19) auto_increment
        primary key,
    name       varchar(64)          not null,
    address    varchar(100)         null,
    code       varchar(64)          not null,
    icon       varchar(32)          null,
    pid        bigint(19)           null,
    seq        tinyint(2) default 0 not null,
    createdate datetime             not null
)
    comment '组织机构';

INSERT INTO rms.organization (id, name, address, code, icon, pid, seq, createdate) VALUES (1, '总经办', '', '01', 'define-depart', null, 0, '2014-02-19 01:00:00');
INSERT INTO rms.organization (id, name, address, code, icon, pid, seq, createdate) VALUES (3, '技术部', '', '02', 'define-depart', null, 1, '2015-10-01 13:10:42');
INSERT INTO rms.organization (id, name, address, code, icon, pid, seq, createdate) VALUES (5, '产品部', '', '03', 'define-depart', null, 2, '2015-12-06 12:15:30');