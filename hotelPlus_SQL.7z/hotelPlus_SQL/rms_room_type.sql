create table room_type
(
    id           int auto_increment
        primary key,
    name         varchar(64)      not null,
    photo        varchar(128)     null,
    price        float(8, 2)      not null,
    live_num     int(2)           not null,
    bed_num      int(2)           not null,
    room_num     int(5)           not null,
    avilable_num int(5)           not null,
    book_num     int(5) default 0 not null,
    lived_num    int(5) default 0 not null,
    status       int(1) default 1 not null,
    remark       varchar(256)     null
);

INSERT INTO rms.room_type (id, name, photo, price, live_num, bed_num, room_num, avilable_num, book_num, lived_num, status, remark) VALUES (1, '单人间', '/static/images/upload/1596783135506.jpg', 168, 1, 1, 12, 8, 3, 2, 0, '单人间只能入住一个人，大概15平米左右！');
INSERT INTO rms.room_type (id, name, photo, price, live_num, bed_num, room_num, avilable_num, book_num, lived_num, status, remark) VALUES (2, '普通大床房', '/web_war/static/images/upload/1596629547214.jpg', 299, 2, 1, 15, 4, 12, -1, 1, '普通大床房，面积25平左右！');
INSERT INTO rms.room_type (id, name, photo, price, live_num, bed_num, room_num, avilable_num, book_num, lived_num, status, remark) VALUES (3, '豪华大床房', '/RMS_war/static/images/upload/1596290382454.jpg', 399, 2, 1, 8, 6, 2, 0, 1, '豪华大床房，面积30平左右！');
INSERT INTO rms.room_type (id, name, photo, price, live_num, bed_num, room_num, avilable_num, book_num, lived_num, status, remark) VALUES (4, '商务大床房', '/HotelSSM/resources/upload/1547865202071.jpg', 429, 2, 1, 10, 8, 2, 0, 1, '商务大床房，面积40平左右！');
INSERT INTO rms.room_type (id, name, photo, price, live_num, bed_num, room_num, avilable_num, book_num, lived_num, status, remark) VALUES (5, '普通标准间', '/HotelSSM/resources/upload/1547863370413.jpg', 199, 2, 2, 11, 2, 9, 0, 1, '普通标准房，面积20平左右！');
INSERT INTO rms.room_type (id, name, photo, price, live_num, bed_num, room_num, avilable_num, book_num, lived_num, status, remark) VALUES (6, '豪华标准房', '/HotelSSM/resources/upload/1547863398297.jpg', 199, 2, 2, 10, 10, 0, 0, 1, '豪华标准房，面积30平左右！');
INSERT INTO rms.room_type (id, name, photo, price, live_num, bed_num, room_num, avilable_num, book_num, lived_num, status, remark) VALUES (7, '商务标准间', '/HotelSSM/resources/upload/1547863458969.jpg', 299, 2, 2, 10, 8, 2, 0, 1, '商务标准间，面积35平左右！');
INSERT INTO rms.room_type (id, name, photo, price, live_num, bed_num, room_num, avilable_num, book_num, lived_num, status, remark) VALUES (8, '普通套房', '/HotelSSM/resources/upload/1547863486075.jpg', 699, 2, 2, 6, 6, 0, 0, 1, '普通套房，面积50平左右！');
INSERT INTO rms.room_type (id, name, photo, price, live_num, bed_num, room_num, avilable_num, book_num, lived_num, status, remark) VALUES (9, '豪华套房', '/HotelSSM/resources/upload/1547863508790.jpg', 899, 2, 2, 5, 2, 3, 0, 1, '豪华套房，面积70平左右！');
INSERT INTO rms.room_type (id, name, photo, price, live_num, bed_num, room_num, avilable_num, book_num, lived_num, status, remark) VALUES (10, '总统套房', '/HotelSSM/resources/upload/1547863538884.jpg', 1299, 2, 2, 3, 0, 3, 0, 0, '总统套房，面积100平，超豪华!');