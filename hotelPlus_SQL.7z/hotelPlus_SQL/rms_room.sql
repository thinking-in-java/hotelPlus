create table room
(
    id           int auto_increment
        primary key,
    photo        varchar(128)     null,
    sn           varchar(32)      not null,
    room_Type_Id int              not null,
    floor_Id     int              not null,
    status       int(1) default 0 not null,
    remark       varchar(128)     null,
    constraint room_ibfk_1
        foreign key (room_Type_Id) references room_type (id),
    constraint room_ibfk_2
        foreign key (floor_Id) references floor (id)
);

create index floorId
    on room (floor_Id);

create index roomTypeId
    on room (room_Type_Id);

INSERT INTO rms.room (id, photo, sn, room_Type_Id, floor_Id, status, remark) VALUES (2, '/static/images/upload/1596783150594.jpg', '1001', 1, 1, 1, '1001单人间、1楼。');
INSERT INTO rms.room (id, photo, sn, room_Type_Id, floor_Id, status, remark) VALUES (3, '/static/images/upload/1596684919126.jpg', '2001', 2, 2, 2, '2楼普通大床房');
INSERT INTO rms.room (id, photo, sn, room_Type_Id, floor_Id, status, remark) VALUES (4, '/static/images/upload/1596684783098.jpg', '3001', 3, 3, 2, '3001豪华大床房');
INSERT INTO rms.room (id, photo, sn, room_Type_Id, floor_Id, status, remark) VALUES (5, '/static/images/upload/1596684857496.jpg', '4001', 4, 4, 0, '商务大床房');
INSERT INTO rms.room (id, photo, sn, room_Type_Id, floor_Id, status, remark) VALUES (6, '/static/images/upload/1596684953710.jpg', '5001', 6, 5, 2, '豪华标准房');
INSERT INTO rms.room (id, photo, sn, room_Type_Id, floor_Id, status, remark) VALUES (8, '/web_war/static/admin/easyui/images/user_photo.jpg', '6001', 10, 6, 0, 'test6666');
INSERT INTO rms.room (id, photo, sn, room_Type_Id, floor_Id, status, remark) VALUES (9, '/static/images/upload/1596783150594.jpg', '7001', 1, 1, 0, '');