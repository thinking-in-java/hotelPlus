create table floor
(
    id     int auto_increment
        primary key,
    name   varchar(32)  not null,
    remark varchar(128) null
);

INSERT INTO rms.floor (id, name, remark) VALUES (1, '1楼', '一楼');
INSERT INTO rms.floor (id, name, remark) VALUES (2, '2楼', '2楼的逃生通道有点阻塞。');
INSERT INTO rms.floor (id, name, remark) VALUES (3, '3楼', '3楼');
INSERT INTO rms.floor (id, name, remark) VALUES (4, '4楼', '4楼监控坏了。');
INSERT INTO rms.floor (id, name, remark) VALUES (5, '5楼', '');
INSERT INTO rms.floor (id, name, remark) VALUES (6, '6楼', '六楼正常');
INSERT INTO rms.floor (id, name, remark) VALUES (7, '7楼', '正常');
INSERT INTO rms.floor (id, name, remark) VALUES (11, '8楼', '正常');
INSERT INTO rms.floor (id, name, remark) VALUES (12, '9楼', '测试啊');
INSERT INTO rms.floor (id, name, remark) VALUES (17, '10楼', '1111111');
INSERT INTO rms.floor (id, name, remark) VALUES (18, '11楼', '1111');
INSERT INTO rms.floor (id, name, remark) VALUES (19, '12楼', '8888');