create table resource
(
    id           bigint(19) auto_increment
        primary key,
    name         varchar(64)          not null,
    url          varchar(100)         null,
    permission   varchar(100)         null,
    description  varchar(255)         null,
    icon         varchar(32)          null,
    pid          bigint(19)           null,
    seq          tinyint(2) default 0 not null,
    status       tinyint(2) default 0 not null,
    resourcetype tinyint(2) default 0 not null,
    createdate   datetime             not null
)
    comment '资源';

INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (1, '系统管理', '', null, '系统管理', 'icon-xitongguanli', null, 3, 0, 0, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (11, '资源管理', '/resource/manager', null, '资源管理', 'icon-ziyuanguanli1', 223, 3, 0, 0, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (12, '角色管理', '/role/manager', null, '角色管理', 'icon-jiaoseguanli', 223, 2, 0, 0, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (13, '用户信息管理', '/user/manager', null, '用户管理', 'icon-untitled85', 223, 1, 0, 0, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (14, '部门资源', '/organization/manager', null, '部门管理', 'icon-bumen1', 223, 4, 0, 0, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (111, '列表', '/resource/treeGrid', 'resource:list', '资源列表', 'define-list', 11, 0, 0, 1, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (112, '添加', '/resource/add', 'resource:add', '资源添加', 'define-add', 11, 0, 0, 1, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (113, '编辑', '/resource/edit', 'resource:edit', '资源编辑', 'define-edit', 11, 0, 0, 1, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (114, '删除', '/resource/delete', 'resource:delete', '资源删除', 'define-del', 11, 0, 0, 1, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (121, '列表', '/role/dataGrid', 'role:list', '角色列表', 'define-list', 12, 0, 0, 1, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (122, '添加', '/role/add', 'role:add', '角色添加', 'define-add', 12, 0, 0, 1, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (123, '编辑', '/role/edit', 'role:edit', '角色编辑', 'define-edit', 12, 0, 0, 1, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (124, '删除', '/role/delete', 'role:delete', '角色删除', 'define-del', 12, 0, 0, 1, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (125, '授权', '/role/grant', 'role:grant', '角色授权', 'define-true', 12, 0, 0, 1, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (131, '列表', '/user/dataGrid', 'user:list', '用户列表', 'define-list', 13, 0, 0, 1, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (132, '添加', '/user/add', 'user:add', '用户添加', 'define-add', 13, 0, 0, 1, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (133, '编辑', '/user/edit', 'user:edit', '用户编辑', 'define-edit', 13, 0, 0, 1, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (134, '删除', '/user/delete', 'user:delete', '用户删除', 'define-del', 13, 0, 0, 1, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (141, '列表', '/organization/treeGrid', 'organization:list', '用户列表', 'define-list', 14, 0, 0, 1, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (142, '添加', '/organization/add', 'organization:add', '部门添加', 'define-add', 14, 0, 0, 1, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (143, '编辑', '/organization/edit', 'organization:edit', '部门编辑', 'define-edit', 14, 0, 0, 1, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (144, '删除', '/organization/delete', 'organization:delete', '部门删除', 'define-del', 14, 0, 0, 1, '2014-02-19 01:00:00');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (221, '日志管理', '/log/manager', null, null, 'icon-rizhiguanli', 1, 1, 0, 0, '2015-12-01 11:44:20');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (222, '后台首页', '/main', '', null, 'icon-houtai', null, 0, 0, 0, '2019-01-11 10:16:17');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (223, '管理员管理', '', null, null, 'icon-guanliyuan', null, 1, 0, 0, '2019-01-11 11:06:20');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (225, '批量删除', '/log/batchDelete', 'log:batchDelete', null, 'define-del', 221, 1, 0, 1, '2019-02-21 15:43:54');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (226, '列表', '/log/dataGrid', 'log:list', null, 'define-list', 221, 0, 0, 1, '2019-02-22 11:31:37');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (228, '楼层管理', '', '', null, 'icon-bumen1', null, 3, 0, 0, '2020-08-04 13:36:12');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (229, '楼层列表', '/floor/list', 'floor:list', null, 'icon-jiaoseguanli', 228, 0, 0, 0, '2020-08-04 13:38:32');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (230, '添加', 'openAdd()', 'floor:add', null, '', 229, 0, 0, 1, '2020-08-04 13:40:10');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (231, '编辑', 'openEdit()', 'floor:edit', null, '', 229, 0, 0, 1, '2020-08-04 16:51:11');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (232, '删除', 'remove()', 'floor:delete', null, '', 229, 0, 0, 1, '2020-08-04 16:52:58');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (233, '房型管理', '', '', null, 'icon-xitongguanli', null, 5, 0, 0, '2020-08-04 16:56:57');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (234, '房型列表', '/room_type/list', 'room_type:list', null, 'icon-rizhiguanli', 233, 0, 0, 0, '2020-08-04 16:58:10');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (235, '添加', 'openAdd()', 'room_type:add', null, '', 234, 0, 0, 1, '2020-08-04 17:04:49');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (236, '编辑', 'openEdit()', 'room_type:edit', null, '', 234, 0, 0, 1, '2020-08-04 17:13:16');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (237, '删除', 'remove()', 'room_type:delete', null, '', 234, 0, 0, 1, '2020-08-04 17:19:26');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (238, '房间管理', '', '', null, 'icon-guanliyuan', null, 6, 0, 0, '2020-08-04 19:23:39');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (239, '房间列表', '/room/list', 'room:list', null, 'icon-jiaoseguanli', 238, 0, 0, 0, '2020-08-04 19:24:21');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (240, '添加', 'openAdd()', 'room:add', null, '', 239, 0, 0, 1, '2020-08-04 19:25:32');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (241, '编辑', 'openEdit()', 'room:edit', null, '', 239, 0, 0, 1, '2020-08-04 19:26:08');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (242, '删除', 'remove()', 'room:delete', null, '', 239, 0, 0, 1, '2020-08-04 19:26:47');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (243, '客户管理', '', '', null, 'icon-untitled85', null, 7, 0, 0, '2020-08-04 20:42:21');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (244, '客户列表', '/account/list', 'account:list', null, 'icon-guanliyuan', 243, 0, 0, 0, '2020-08-04 20:43:16');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (245, '添加', 'openAdd', 'account:add', null, '', 244, 0, 0, 1, '2020-08-04 20:44:19');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (246, '修改', 'openEdit()', 'account:edit', null, '', 244, 0, 0, 1, '2020-08-04 20:45:14');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (247, '删除', 'remove', 'account:delete', null, '', 244, 0, 0, 1, '2020-08-04 21:24:19');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (248, '预定管理', '', '', null, 'icon-houtai', null, 8, 0, 0, '2020-08-04 21:34:22');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (249, '预定列表', '/book_order/list', 'book_order:list', null, 'icon-rizhiguanli1', 248, 0, 0, 0, '2020-08-04 21:41:20');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (250, '新增预定', 'openAdd()', 'book_order:add', null, '', 249, 0, 0, 1, '2020-08-04 21:42:30');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (251, '修改预定', 'openEdit()', 'book_order:edit', null, '', 249, 0, 0, 1, '2020-08-04 21:43:17');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (252, '入住管理', '', '', null, 'icon-guanliyuan', null, 9, 0, 0, '2020-08-04 22:42:54');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (253, '入住列表', '/checkin/list', 'checkin:list', null, '', 252, 0, 0, 0, '2020-08-04 22:43:35');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (254, '登记入住', 'openAdd()', 'checkin:add', null, '', 253, 0, 0, 1, '2020-08-04 22:44:55');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (255, '编辑入住', 'openEdit()', 'checkin:edit', null, '', 253, 0, 0, 1, '2020-08-04 22:45:40');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (256, '登记退房', 'openCheckOut()', 'checkin:delete', null, '', 253, 0, 0, 1, '2020-08-04 22:46:35');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (257, '统计分析', '', '', null, 'icon-rizhiguanli', null, 10, 0, 0, '2020-08-04 23:42:48');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (258, '统计图表', '/stats/stats', 'stats:list', null, 'icon-rizhiguanli', 257, 0, 0, 0, '2020-08-04 23:43:32');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (259, '按月统计', 'statsByMonth()', '', null, '', 258, 0, 0, 1, '2020-08-04 23:45:02');
INSERT INTO rms.resource (id, name, url, permission, description, icon, pid, seq, status, resourcetype, createdate) VALUES (260, '按日统计', 'statsByDay()', '', null, '', 258, 0, 0, 1, '2020-08-04 23:45:27');