create table role
(
    id          bigint(19) auto_increment
        primary key,
    name        varchar(64)          not null,
    seq         tinyint(2) default 0 not null,
    description varchar(255)         null,
    status      tinyint(2) default 0 not null
)
    comment '角色';

INSERT INTO rms.role (id, name, seq, description, status) VALUES (1, '超级管理员', 0, '超级管理员', 0);
INSERT INTO rms.role (id, name, seq, description, status) VALUES (2, '技术部经理', 0, '技术部经理', 1);
INSERT INTO rms.role (id, name, seq, description, status) VALUES (8, '测试账户', 0, '测试账户', 0);
INSERT INTO rms.role (id, name, seq, description, status) VALUES (10, '部门管理员', 0, '管理相关部门', 0);