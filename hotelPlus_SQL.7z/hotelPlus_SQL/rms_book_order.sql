create table book_order
(
    id           int auto_increment
        primary key,
    account_id   int              not null,
    room_type_id int              not null,
    name         varchar(32)      not null,
    id_card      varchar(32)      null,
    mobile       varchar(16)      null,
    status       int(1) default 0 null,
    arrive_date  varchar(32)      null,
    leave_date   varchar(32)      not null,
    remark       varchar(128)     null,
    create_time  datetime         not null,
    pay_status   int    default 0 not null,
    constraint book_order_ibfk_1
        foreign key (account_id) references account (id),
    constraint book_order_ibfk_2
        foreign key (room_type_id) references room_type (id)
);

create index accountId
    on book_order (account_id);

create index roomTypeId
    on book_order (room_type_id);

